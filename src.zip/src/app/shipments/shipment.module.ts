export class Shipment{


  FullName:any;
  MobileNumber:any;
  BuildingName:any;
  Area:any;
  State:any;
  City:any;
  Pincode:any


}
